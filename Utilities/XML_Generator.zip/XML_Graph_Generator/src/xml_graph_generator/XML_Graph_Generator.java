/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package xml_graph_generator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 *  A very hacky way of generating a random node file
 * 
 * @author Jon
 */
public class XML_Graph_Generator {
    private String fileName = "nodes.xml";
    private String startIP = "10.0.0.1";
    private String[] ipList = null;
    private int numNodes = 5;
    private double wMin = 0.01;
    private double wMax = 2.0;
    private double cMin = 0.01;
    private double cMax = 2.0;
    private int nMin = 1;
    private int nMax = 4;
    private Random randGen;
    
    private String xmlHeader = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>";
    private String root_otag = "<doc>";
    private String root_ctag = "</doc>";
    private String node_otag = "<node>";
    private String node_ctag = "</node>";
    private String ip_otag = "<id>";
    private String ip_ctag = "</id>";
    
    private ArrayList<String> xmlDoc = null;
    
    public XML_Graph_Generator( String _fileName ){
        if( _fileName == null ){
            println( "filename not specified, using defualt: " + fileName );
        } else {
            // TODO - check filename for .xml
            fileName = _fileName;
            println( "setting filename to: " + fileName );
        }
        randGen = new Random();
        xmlDoc = new ArrayList<>();        
    }
    
    public void generateFile(){
        generateNodes();
        println( "generating xml structure" );
        xmlDoc.add( xmlHeader + "\n" );
        xmlDoc.add( root_otag + "\n" );
        
        // for each node
        // ranomly generate number of paths from that node in range
        // randonly generate the neighbor array corresponding to the paths
        // randomly generate the respective weights/capacities
        // add to XML doc structure
        for( int n = 0; n < numNodes; n++ ){
            String node = ipList[n];
            int paths = randInt( nMin, nMax );
            //println( "node: " + node + " - number of paths chosen: " + paths );
            ArrayList<String> nbrs = new ArrayList<>();
            double[] wts = new double[paths];
            double[] caps = new double[paths];
            for( int p = 0; p < paths; p++ ){
                String nn = ipList[ randGen.nextInt(numNodes) ];
                while( (nn.equals(node)) || (nbrs.contains(nn)) ){
                    //println( "duplicate: " + nn );
                    nn = ipList[ randGen.nextInt(numNodes) ];                    
                }
                nbrs.add(nn);
                //println( "pushing on: " + nn );
                wts[p] = randDouble(wMin, wMax);
                caps[p] = randDouble(cMin, cMax);
            }
            appendElement(node, nbrs.toArray( new String[nbrs.size()] ), wts, caps);
        }        
        
        xmlDoc.add( root_ctag + "\n" );
        //printXMLdoc();
        writeXMLtofile();
    }
    
    // TODO - lots of error checking here
    private void appendElement( String ip, String[] neighb, double[] weights, double[] caps ){
        xmlDoc.add( "    " + node_otag + "\n" );
        xmlDoc.add( "        " + ip_otag + ip + ip_ctag + "\n" );
        for( int n = 0; n < neighb.length; n++ ){
            xmlDoc.add( "        <neighbor ip=\"" + neighb[n] + "\">\n" );
            xmlDoc.add( "            <weight>" + weights[n] + "</weight>\n" );
            xmlDoc.add( "            <capacity>" + caps[n] + "</capacity>\n" );
            xmlDoc.add( "        </neighbor>\n" );
        }
        xmlDoc.add( "    " + node_ctag + "\n" );
    }
    
    private void generateNodes(){
        String base = startIP.substring(0, (startIP.lastIndexOf('.')+1));
        String nodeStr = (startIP.substring(startIP.lastIndexOf('.')+1));
        int nodeNum = Integer.parseInt( nodeStr );
        
        // TODO - error checking here
        println( "generating the node list" );
        println( "using base address of: " + base );
        println( "starting node string is: " + nodeStr );
        println( "starting node number is: " + nodeNum );
        
        ipList = new String[numNodes];
        for( int n = 0; n < numNodes; n++ ){
            String node = base + Integer.toString(nodeNum);
            println( "adding node to list, IP: " + node );
            ipList[n] = node;
            nodeNum++;
        }
        
    }
    
    public void setNeighborRange( int min, int max ){
        if( min < 1 ){
            println( "neighbor min value in range less than 1, using default: " + nMin );
        } else {
            nMin = min;
            println( "setting neighbor range min to: " + nMin );
        }
        if( (max < 1) || (max < min) || (max >= numNodes) ){
            println( "neighbor max value in range less than 1 or less than min or greatern/equal to number of nodes, using default: " + nMax );
        } else {
            nMax = max;
            println( "setting neighbor range max to: " + nMax );
        }
    }
    
    public void setCapacityRange( double min, double max ){
        if( min < (double) 0.01 ){
            println( "capacity min in range less than 0.01, using default: " + cMin );
        } else {
            cMin = min;
            println( "setting capacity min to: " + cMin );
        }
        if( (max < (double) 0.01) || (max < min) ){
            println( "capacity max in range less than 0.01 or less than min, using default: " + cMax );
        } else {
            cMax = max;
            println( "setting capacity max to: " + wMax );
        }
    }
    
    public void setWeightRange( double min, double max ){
        if( min < (double) 0.01 ){
            println( "weight min in range less than 0.01, using default: " + wMin );
        } else {
            wMin = min;
            println( "setting weight min to: " + wMin );
        }
        if( (max < (double) 0.01) || (max < min) ){
            println( "weight max in range less than 0.01 or less than min, using default: " + wMax );
        } else {
            wMax = max;
            println( "setting weight max to: " + wMax );
        }
    }
    
    public void setIPRange( String _startIp, int _numNodes ){
        if( _startIp == null ){
            println( "start IP address not specified, using default: " + startIP );
        } else {
            // TODO - check _startIp with regex for correctness XXX.XXX.XXX.XXX
            startIP = _startIp;
            println( "setting startIP to: " + startIP );
        }
        if( _numNodes < 1 ){
            println( "number of nodes in range is less than 1, using default: " + numNodes );
        } else {
            numNodes = _numNodes;
            println( "setting number of nodes to use to: " + numNodes );
        }
    }
    
    private double randDouble( double min, double max ){
        if( min < 0 )
            min = 0.0;
        if( max > Double.MAX_VALUE )
            max = Double.MAX_VALUE;
        if( max < min ){
            double t = min;
            min = max;
            max = t;
        }
        double precise = ( min + (Math.random() * ((max-min)+1) ) );
        return roundTwoDecimals( precise );
    }
    
    private double roundTwoDecimals(double d) {
        DecimalFormat twoDForm = new DecimalFormat("#.##");
        return Double.valueOf(twoDForm.format(d));
    }
    
    private int randInt( int min, int max ){
        if( min < 0 )
            min = 0;
        if( max > Integer.MAX_VALUE )
            max = Integer.MAX_VALUE;
        if( max < min ){
            int t = min;
            min = max;
            max = t;
        }
        return ( min + (randGen.nextInt((max-min)+1)) );
    }
    
    private void printXMLdoc(){
        println( "nprinting the xml doc\n" );
        for( String line : xmlDoc ){
            System.out.print( line );
        }
        println( "\ndone\n" );
    }
    
    private void writeXMLtofile(){
        try{
            FileWriter fstream = new FileWriter( fileName );
            BufferedWriter out = new BufferedWriter(fstream);
            
            println( "writing the xml doc to file" );
            for( String line : xmlDoc ){
                out.write( line );
            }
            println( "done" );
            
            out.close();
        }catch (Exception e){//Catch exception if any
            println("error writing xml file: " + e.getMessage());
        }
    }
    
    private void println( String msg ){
        System.out.println( msg );
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        XML_Graph_Generator xmlGen = new XML_Graph_Generator( "nodes.xml" );
        xmlGen.setIPRange( "10.0.0.1", 15 );
        xmlGen.setNeighborRange(1, 3);
        xmlGen.setWeightRange( 0.01, 2.0 );
        xmlGen.setCapacityRange( 0.01, 2.0 );
        xmlGen.generateFile();
    }
}
